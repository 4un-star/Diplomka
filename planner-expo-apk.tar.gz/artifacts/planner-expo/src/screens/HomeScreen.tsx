import React, { useCallback, useEffect } from "react";
import {
  View,
  Text,
  StyleSheet,
  ScrollView,
  RefreshControl,
  TouchableOpacity,
} from "react-native";
import { SafeAreaView } from "react-native-safe-area-context";
import { useSQLiteContext } from "expo-sqlite";
import { useQuery, useQueryClient } from "@tanstack/react-query";
import { Ionicons } from "@expo/vector-icons";
import { isThisWeek, parseISO, isToday, isTomorrow, format } from "date-fns";
import { ru } from "date-fns/locale";

import { getAllTasks, getTaskStats, getMoodleCache, Task, TaskStats } from "@/db";
import { useAuth } from "@/context/AuthContext";
import { colors, spacing, radius, fontSize, shadow } from "@/theme";
import { TASK_TYPES } from "@/config";
import {
  computeRisks,
  Risk,
  MoodleGrade,
  MissingAssignment,
} from "@/api/moodle";
import { requestNotificationPermissions } from "@/notifications";

function RiskCard({ risk }: { risk: Risk }) {
  const bg =
    risk.level === "danger"
      ? colors.destructiveLight
      : "#fff8e7";
  const border =
    risk.level === "danger"
      ? colors.destructive + "50"
      : "#f59e0b50";
  const iconColor =
    risk.level === "danger" ? colors.destructive : "#d97706";

  return (
    <View style={[styles.riskCard, { backgroundColor: bg, borderColor: border }]}>
      <Ionicons
        name={risk.icon as any}
        size={20}
        color={iconColor}
        style={{ marginTop: 1 }}
      />
      <View style={styles.riskBody}>
        <Text style={[styles.riskTitle, { color: iconColor }]}>
          {risk.title}
        </Text>
        <Text style={styles.riskDetail}>{risk.detail}</Text>
      </View>
    </View>
  );
}

function StatCard({
  label,
  value,
  color,
  icon,
}: {
  label: string;
  value: number;
  color: string;
  icon: keyof typeof Ionicons.glyphMap;
}) {
  return (
    <View style={[styles.statCard, shadow.card]}>
      <View style={[styles.statIcon, { backgroundColor: color + "20" }]}>
        <Ionicons name={icon} size={20} color={color} />
      </View>
      <Text style={styles.statValue}>{value}</Text>
      <Text style={styles.statLabel}>{label}</Text>
    </View>
  );
}

function formatDateLabel(dateStr: string): string {
  const d = parseISO(dateStr);
  if (isToday(d)) return "Сегодня";
  if (isTomorrow(d)) return "Завтра";
  return format(d, "d MMM", { locale: ru });
}

export default function HomeScreen() {
  const db = useSQLiteContext();
  const queryClient = useQueryClient();
  const { user, logout } = useAuth();

  useEffect(() => {
    requestNotificationPermissions();
  }, []);

  const { data: stats, isRefetching: sr, refetch: refetchStats } =
    useQuery<TaskStats>({
      queryKey: ["stats"],
      queryFn: () => getTaskStats(db),
    });

  const { data: tasks = [], isRefetching: tr, refetch: refetchTasks } =
    useQuery<Task[]>({
      queryKey: ["tasks"],
      queryFn: () => getAllTasks(db),
    });

  const onRefresh = useCallback(() => {
    refetchStats();
    refetchTasks();
    queryClient.invalidateQueries({ queryKey: ["risks"] });
  }, []);

  // Риски рассчитываются из кэша Moodle
  const { data: risks = [] } = useQuery<Risk[]>({
    queryKey: ["risks"],
    queryFn: () => {
      const rawGrades = getMoodleCache(db, "grades");
      const rawMissed = getMoodleCache(db, "missedHours");
      const rawMissing = getMoodleCache(db, "missingAssignments");
      const grades: MoodleGrade[] = rawGrades ? JSON.parse(rawGrades) : [];
      const missed: Record<string, number> = rawMissed
        ? JSON.parse(rawMissed)
        : {};
      const missing: MissingAssignment[] = rawMissing
        ? JSON.parse(rawMissing)
        : [];
      return computeRisks(grades, missed, missing);
    },
  });

  const upcoming = tasks
    .filter((t) => !t.completed && isThisWeek(parseISO(t.date), { locale: ru }))
    .sort((a, b) => new Date(a.date).getTime() - new Date(b.date).getTime())
    .slice(0, 5);

  const greeting = () => {
    const h = new Date().getHours();
    if (h < 12) return "Доброе утро";
    if (h < 18) return "Добрый день";
    return "Добрый вечер";
  };

  return (
    <SafeAreaView style={styles.safe}>
      <ScrollView
        contentContainerStyle={styles.content}
        refreshControl={
          <RefreshControl
            refreshing={sr || tr}
            onRefresh={onRefresh}
            tintColor={colors.primary}
          />
        }
      >
        {/* Шапка */}
        <View style={styles.header}>
          <View>
            <Text style={styles.greeting}>{greeting()}</Text>
            <Text style={styles.username}>
              {user?.username ?? "Студент"}
            </Text>
          </View>
          <TouchableOpacity onPress={logout} style={styles.logoutBtn}>
            <Ionicons
              name="log-out-outline"
              size={22}
              color={colors.textSecondary}
            />
          </TouchableOpacity>
        </View>

        {/* Карточки рисков */}
        {risks.length > 0 && (
          <>
            <Text style={styles.sectionTitle}>
              <Ionicons
                name="warning-outline"
                size={16}
                color={colors.destructive}
              />{" "}
              Риски ({risks.length})
            </Text>
            <View style={styles.riskList}>
              {risks.map((r) => (
                <RiskCard key={r.id} risk={r} />
              ))}
            </View>
          </>
        )}

        {/* Статистика */}
        <Text style={styles.sectionTitle}>Статистика</Text>
        <View style={styles.statsRow}>
          <StatCard
            label="Всего"
            value={stats?.total ?? 0}
            color={colors.primary}
            icon="list-outline"
          />
          <StatCard
            label="Выполнено"
            value={stats?.completed ?? 0}
            color={colors.success}
            icon="checkmark-circle-outline"
          />
          <StatCard
            label="Просрочено"
            value={stats?.overdue ?? 0}
            color={colors.destructive}
            icon="alert-circle-outline"
          />
        </View>

        {/* Ближайшие задачи */}
        <Text style={styles.sectionTitle}>На этой неделе</Text>
        {upcoming.length === 0 ? (
          <View style={[styles.emptyCard, shadow.card]}>
            <Ionicons
              name="checkmark-done-outline"
              size={32}
              color={colors.textSecondary}
            />
            <Text style={styles.emptyText}>Нет задач на эту неделю</Text>
            <Text style={styles.emptyHint}>
              Синхронизируйтесь с Moodle или добавьте задачи вручную
            </Text>
          </View>
        ) : (
          <View style={styles.taskList}>
            {upcoming.map((task) => {
              const typeInfo = TASK_TYPES[task.type] ?? TASK_TYPES.homework;
              return (
                <View key={task.id} style={[styles.taskRow, shadow.card]}>
                  <View
                    style={[
                      styles.taskTypeBar,
                      { backgroundColor: typeInfo.color },
                    ]}
                  />
                  <View style={styles.taskContent}>
                    <Text style={styles.taskTitle} numberOfLines={1}>
                      {task.title}
                    </Text>
                    <Text style={styles.taskSub}>
                      {task.subject} · {typeInfo.label}
                    </Text>
                  </View>
                  <View style={styles.taskDate}>
                    <Text style={styles.taskDateText}>
                      {formatDateLabel(task.date)}
                    </Text>
                  </View>
                </View>
              );
            })}
          </View>
        )}
      </ScrollView>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  safe: { flex: 1, backgroundColor: colors.background },
  content: { padding: spacing.lg, gap: spacing.md },
  header: {
    flexDirection: "row",
    justifyContent: "space-between",
    alignItems: "center",
    marginBottom: spacing.sm,
  },
  greeting: { fontSize: fontSize.sm, color: colors.textSecondary },
  username: { fontSize: fontSize.xl, fontWeight: "600", color: colors.text },
  logoutBtn: { padding: spacing.sm },
  sectionTitle: {
    fontSize: fontSize.md,
    fontWeight: "600",
    color: colors.text,
    marginTop: spacing.xs,
  },
  // Риски
  riskList: { gap: spacing.sm },
  riskCard: {
    flexDirection: "row",
    gap: spacing.sm,
    padding: spacing.md,
    borderRadius: radius.md,
    borderWidth: 1,
    alignItems: "flex-start",
  },
  riskBody: { flex: 1, gap: 2 },
  riskTitle: { fontSize: fontSize.sm, fontWeight: "600" },
  riskDetail: { fontSize: fontSize.xs, color: colors.textSecondary, lineHeight: 17 },
  // Статистика
  statsRow: { flexDirection: "row", gap: spacing.sm },
  statCard: {
    flex: 1,
    backgroundColor: colors.card,
    borderRadius: radius.md,
    padding: spacing.md,
    alignItems: "center",
    gap: spacing.xs,
    borderWidth: 1,
    borderColor: colors.border,
  },
  statIcon: {
    width: 40,
    height: 40,
    borderRadius: radius.full,
    justifyContent: "center",
    alignItems: "center",
  },
  statValue: { fontSize: fontSize.xl, fontWeight: "700", color: colors.text },
  statLabel: {
    fontSize: fontSize.xs,
    color: colors.textSecondary,
    textAlign: "center",
  },
  // Задачи
  taskList: { gap: spacing.sm },
  taskRow: {
    flexDirection: "row",
    backgroundColor: colors.card,
    borderRadius: radius.md,
    overflow: "hidden",
    borderWidth: 1,
    borderColor: colors.border,
    alignItems: "center",
  },
  taskTypeBar: { width: 4, alignSelf: "stretch" },
  taskContent: { flex: 1, padding: spacing.md, gap: 2 },
  taskTitle: { fontSize: fontSize.md, fontWeight: "500", color: colors.text },
  taskSub: { fontSize: fontSize.xs, color: colors.textSecondary },
  taskDate: { paddingRight: spacing.md },
  taskDateText: {
    fontSize: fontSize.xs,
    fontWeight: "600",
    color: colors.primary,
  },
  emptyCard: {
    backgroundColor: colors.card,
    borderRadius: radius.md,
    padding: spacing.xl,
    alignItems: "center",
    gap: spacing.xs,
    borderWidth: 1,
    borderColor: colors.border,
  },
  emptyText: {
    fontSize: fontSize.sm,
    color: colors.textSecondary,
    fontWeight: "500",
  },
  emptyHint: {
    fontSize: fontSize.xs,
    color: colors.textSecondary,
    textAlign: "center",
  },
});
